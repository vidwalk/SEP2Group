package zair.domain.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Flight implements Serializable{
	private ArrayList<Seat> seats;
	private Date dateDeparture;
	private Date dateArrival;
	private AbstractPlaces origin;
	private AbstractPlaces destination;
	private AbstractTime timeDeparture;
	private AbstractTime timeArrival;
	private double price;
	private String flightID;

	public Flight(Date dateDeparture, Date dateArrival, String origin, String destination, String timeDeparture,
			String timeArrival, double price) {
		this.dateDeparture = dateDeparture;
		this.dateArrival = dateArrival;
		this.origin = PlacesFactory.getPlace(origin);
		this.destination = PlacesFactory.getPlace(destination);
		this.timeDeparture = TimeFactory.getTime(timeDeparture);
		this.timeArrival = TimeFactory.getTime(timeArrival);
		this.price = price;
		flightID = createFlightID();
		seats = new ArrayList<>();
		for (int i = 0; i < 10; i++)
		{
		   String value = Integer.toString((i+1));
		   Seat seat = new Seat("A" + value);
		   seats.add(seat);
		}
		for (int i = 10; i < 20; i++)
      {
		   String value = Integer.toString(((i % 10)+1));
         Seat seat = new Seat("B" + value);
         seats.add(seat);
      }
		for (int i = 20; i < 30; i++)
      {
		   String value = Integer.toString(((i % 20)+1));
         Seat seat = new Seat("C" + value);
         seats.add(seat);
      }
		for (int i = 30; i < 40; i++)
      {
		   String value = Integer.toString(((i % 30)+1));
         Seat seat = new Seat("D" + value);
         seats.add(seat);
      }
		for (int i = 40; i < 50; i++)
      {
		   String value = Integer.toString(((i % 40)+1));
         Seat seat = new Seat("E" + value);
         seats.add(seat);
      }
		for (int i = 50; i < 60; i++)
      {
		   String value = Integer.toString(((i % 50)+1));
         Seat seat = new Seat("F" + value);
         seats.add(seat);
      }
	}

	public ArrayList<Seat> getSeats() {
		return seats;
	}

	private String createFlightID() {
		String[] parts = dateDeparture.toString().split("/");
		String[] parts1 = timeDeparture.toString().split(":");
		String id = "";
		id += destination.getInitials();
		id += origin.getInitials();
		id += parts[0] + parts[1] + parts[2];
		id += parts1[0] + parts1[1];

		return id;
	}

	public Date getDateDeparture() {
		return dateDeparture;
	}

	public void setDateDeparture(Date dateDeparture) {
		this.dateDeparture = dateDeparture;
	}

	public Date getDateArrival() {
		return dateArrival;
	}

	public void setDateArrival(Date dateArrival) {
		this.dateArrival = dateArrival;
	}

	public AbstractPlaces getOrigin() {
		return origin;
	}

	public void setOrigin(AbstractPlaces origin) {
		this.origin = origin;
	}

	public AbstractPlaces getDestination() {
		return destination;
	}

	public void setDestination(AbstractPlaces destination) {
		this.destination = destination;
	}

	public AbstractTime getTimeDeparture() {
		return timeDeparture;
	}

	public void setTimeDeparture(AbstractTime timeDeparture) {
		this.timeDeparture = timeDeparture;
	}

	public AbstractTime getTimeArrival() {
		return timeArrival;
	}

	public void setTimeArrival(AbstractTime timeArrival) {
		this.timeArrival = timeArrival;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public ArrayList<Seat> getAvailableSeats()
	{
	   ArrayList<Seat> output = new ArrayList<>();
	   for (int i = 0; i < seats.size(); i++)
	   {
	      if (seats.get(i).isBooked() == false)
	      {
	         output.add(seats.get(i));
	      }
	   }

	   return output;
	}

	public int getNumberOfTicketsLeft() {
		return getAvailableSeats().size();
	}

	public void setSeatOccupied(String value)
	{
	   for (int i = 0; i < seats.size(); i++)
	   {
	      if (seats.get(i).getSeatValue().equals(value))
	      {
	         seats.get(i).setBooked();
	      }
	   }
	}

	public String getId() {
		return flightID;
	}

   public void setAllSeats(ArrayList<Seat> seats)
   { this.seats = new ArrayList<>();

      for (int i = 0; i < seats.size(); i++)
      {
         this.seats.add(seats.get(i));
      }
   }

	public ArrayList<Seat> getAllSeats()
	{
	   return seats;
	}
}

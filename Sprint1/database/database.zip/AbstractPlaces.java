package zair.domain.model;

import java.io.Serializable;

public abstract class AbstractPlaces implements Serializable {
	private String city;
	private String country;
	private String initials;

	public AbstractPlaces(String city) {
		this.city = Character.toUpperCase(city.charAt(0)) + city.substring(1).toLowerCase();
		setLocation();
	}

	public String getLocation() {
		return city + ", " + initials + ", " + country;
	}

	public String getInitials() {
		return initials;
	}

	private void setLocation() {

		if (city.equals("Copenhagen") || city.equals("Cph")) {
			country = "Denmark";
			initials = "CPH";
			city = "Copenhagen";
		} else if (city.equals("Bucharest") || city.equals("Buc")) {
			country = "Romania";
			initials = "BUC";
			city = "Bucharest";
		} else if (city.equals("London") || city.equals("Lon")) {
			country = "United Kingdom";
			initials = "LON";
			city = "London";
		} else if (city.equals("Warsaw") || city.equals("War")) {
			country = "Poland";
			initials = "WAR";
			city = "Warsaw";
		} else if (city.equals("Riga") || city.equals("Rig")) {
			country = "Latvia";
			initials = "RIG";
			city = "Riga";
		} else if (city.equals("Frankfurt") || city.equals("Fra")) {
			country = "Germany";
			initials = "FRA";
			city = "Frankfurt";
		} else if (city.equals("Madrid") || city.equals("Mad")) {
			country = "Spain";
			initials = "MAD";
			city = "Madrid";
		}
		// add more
	}
}

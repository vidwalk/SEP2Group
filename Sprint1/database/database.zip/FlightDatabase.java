package zair.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;

import utility.persistence.MyDatabase;
import zair.domain.model.Credentials;
import zair.domain.model.Customer;
import zair.domain.model.Date;
import zair.domain.model.Flight;
import zair.domain.model.Seat;
import zair.domain.model.Ticket;

public class FlightDatabase implements FlightTarget {
	private Connection c = null;
	private Statement stmt = null;
	private MyDatabase database;

	///////////////////////////////// DB
	///////////////////////////////// SETUP///////////////////////////////////////////////

	public FlightDatabase(String password, String database) {
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + database, "postgres", password);
			c.setAutoCommit(true);
			System.out.println("Opened database successfully");

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			System.out.println("Database query ok ");
		}
	}

	public void addFlight(Flight flight) {
		try {
			stmt = c.createStatement();
			String dateOfArrival = flight.getDateArrival().toString();
			String dateOfDeparture = flight.getDateDeparture().toString();
			String origin = "" + flight.getOrigin().getInitials();
			String destination = "" + flight.getDestination().getInitials();
			String timeDeparture = flight.getTimeDeparture().toString();
			String timeArrival = flight.getTimeArrival().toString();
			String price = "" + flight.getPrice();
			String numberOfTickets = "" + 50;

			String flightID = flight.getId().toString();

			System.out.println("INSERT INTO zair.\"Flight\" " + "VALUES ('" + flightID + "', '" + origin + "', '"
					+ destination + "', '" + dateOfDeparture + "', '" + dateOfArrival + "', '" + timeDeparture + "', '"
					+ timeArrival + "', '" + numberOfTickets + "', '" + price + ");");

			stmt.executeUpdate("INSERT INTO zair.\"Flight\" " + "VALUES ('" + flightID + "', '" + origin + "', '"
					+ destination + "', '" + dateOfArrival + "', '" + dateOfDeparture + "', '" + timeDeparture + "', '"
					+ timeArrival + "', " + numberOfTickets + ", " + price + ");");

		} catch (SQLException e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			System.out.println("Database query ok ");
		}
	}

	@Override
	public void removeFlight(int index) {
		try {
			stmt = c.createStatement();
			stmt.executeUpdate("DELETE FROM Flight WHERE index ='" + index + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public Flight[] getTodayFlights() {

		Date date = new Date(); // it will create todays date
		Flight[] fl = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Flight\" WHERE dateOfDeparture = ? ";
			PreparedStatement preparedStatement = c.prepareStatement(selectSQL);
			preparedStatement.setString(1, date.toString());
			ResultSet resultSet = preparedStatement.executeQuery();
			int amount = resultSet.getInt("total");

			String selectSQL1 = "SELECT * FROM Flight WHERE dateOfDeparture = ? ";
			PreparedStatement preparedStatement1 = c.prepareStatement(selectSQL1);
			preparedStatement.setString(1, date.toString());
			ResultSet resultSet1 = preparedStatement1.executeQuery();

			fl = new Flight[amount];
			int i = 0;

			while (resultSet.next()) {

				Date dateDeparture = StringToDate(resultSet1.getString("dateOfDeparture"));
				Date dateArrival = StringToDate(resultSet1.getString("dateOfArrival"));
				String origin = resultSet1.getString("origin");
				String destination = resultSet1.getString("destination");
				String timeDeparture = resultSet1.getString("timeOfDeparture");
				String timeArrival = resultSet1.getString("timeOfArrival");
				double price = resultSet1.getDouble("price");
				int numberOfTicketsLeft = resultSet1.getInt("nrOfTicketsLeft");
				int nrOfTickets = resultSet1.getInt("nrOfTickets");

				fl[i] = new Flight(dateDeparture, dateArrival, origin, destination, timeDeparture, timeArrival, price);

				i++;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fl;
	}

	private Date StringToDate(String string) {
		int year = Integer.parseInt(string.substring(0, 4));
		int day = Integer.parseInt(string.substring(5, 7));
		int month = Integer.parseInt(string.substring(8, 10));

		Date date = new Date(day, month, year);
		return date;
	}

	@Override
	public Flight[] getAllFlights() {
		Flight[] fl = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Flight\"";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();
			resultSet1.next();
			int amount = resultSet1.getInt("total");
			fl = new Flight[amount];
			selectSQL = "SELECT * FROM zair.\"Flight\"";
			preparedStatement = c.prepareStatement(selectSQL);
			resultSet1 = preparedStatement.executeQuery();
			int i = 0;
			while (resultSet1.next()) {
				String origin = resultSet1.getString("origin");
				String destination = resultSet1.getString("destination");
				Date dateDeparture = StringToDate(resultSet1.getString("dateOfDeparture"));
				Date dateArrival = StringToDate(resultSet1.getString("dateOfArrival"));
				String timeDeparture = resultSet1.getString("timeOfDeparture");
				String timeArrival = resultSet1.getString("timeOfArrival");
				double price = resultSet1.getDouble("price");
				fl[i] = new Flight(dateDeparture, dateArrival, origin, destination, timeDeparture, timeArrival, price);
				ArrayList<Seat> seats = new ArrayList<Seat>();
				Seat[] s1 = getAllSeats("CPHBUC101020180800");
				for (int j = 0; j < s1.length; j++) {
					seats.add(s1[j]);
				}
				fl[i].setAllSeats(seats);
				i++;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fl;

	}

	@Override
	public Flight getFlight(String id) {

		Flight fl = null;
		try {
			stmt = c.createStatement();

			String selectSQL = "SELECT * FROM zair.\"Flight\" WHERE \"flightID\" = '" + id + "'";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();

			while (resultSet1.next()) {

				Date dateDeparture = StringToDate(resultSet1.getString("dateOfDeparture"));
				Date dateArrival = StringToDate(resultSet1.getString("dateOfArrival"));
				String origin = resultSet1.getString("origin");
				String destination = resultSet1.getString("destination");
				String timeDeparture = resultSet1.getString("timeOfDeparture");
				String timeArrival = resultSet1.getString("timeOfArrival");
				double price = resultSet1.getDouble("price");
				fl = new Flight(dateDeparture, dateArrival, origin, destination, timeDeparture, timeArrival, price);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return fl;
	}

	@Override
	public void addCustomer(Customer customer) {
		try {
			stmt = c.createStatement();
			String customerID = customer.getCustomerNo();
			String fname = customer.getFname();
			String lname = customer.getLname();
			String email = customer.getEmail();
			String phone = customer.getPhone();
			String passportNo = customer.getPassportNo();
			String userID = customer.getCredentials().getUserId();
			String password = customer.getCredentials().getPassword();
			System.out.println("INSERT INTO zair.\"Customer\" " + "VALUES ('" + customerID + "', '" + fname + "', '"
					+ lname + "', '" + email + "', '" + passportNo + "', '" + phone + "');");

			stmt.executeUpdate("INSERT INTO zair.\"Customer\" " + "VALUES ('" + customerID + "', '" + fname + "', '"
					+ lname + "', '" + email + "', '" + passportNo + "', '" + phone + "');");
			stmt = c.createStatement();
			System.out.println("INSERT INTO zair.\"CustomerCredentials\" " + "VALUES ('" + customerID + "', '"
					+ userID + "', '" + password + "');");
			stmt.executeUpdate("INSERT INTO zair.\"CustomerCredentials\" " + "VALUES ('" + customerID + "', '"
					+ userID + "', '" + password + "');");

		} catch (SQLException e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			System.out.println("Database query ok ");
		}
	}

	@Override
	public Customer getCustomer(String id) {
		Customer customer = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT * FROM zair.\"Customer\" WHERE \"customerID\" = " + id + ";";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();

			while (resultSet1.next()) {

				String customerID = resultSet1.getString("customerID");
				String fname = resultSet1.getString("fName");
				String lname = resultSet1.getString("lName");
				String email = resultSet1.getString("email");
				String passportNo = resultSet1.getString("passportNo");
				String phone = resultSet1.getString("phone");

				customer = new Customer(fname, lname, email, phone, passportNo, "", "");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public Credentials getCustomerCredentials(String id) {
		Credentials credentials = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT * FROM zair.\"CustomerCredentials\" WHERE \"customerID\" = '" + id + "';";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();

			while (resultSet1.next()) {
				String userID = resultSet1.getString("userID");
				String password = resultSet1.getString("password");

				credentials = new Credentials(userID, password);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return credentials;
	}

	@Override
	public void saveSeats(Flight flight) {
		for (int i = 0; i < flight.getAllSeats().size(); i++) {
			try {
				stmt = c.createStatement();
				String seatPo = flight.getAllSeats().get(i).getSeatValue();
				String seatValue = "" + flight.getAllSeats().get(i).isBooked();
				String flightID = "" + flight.getId();

				System.out.println("INSERT INTO zair.\"Seats\" " + "VALUES ('" + seatPo + "', '" + seatValue + "', '"
						+ flightID + "');");

				stmt.executeUpdate("INSERT INTO zair.\"Seats\" " + "VALUES ('" + seatPo + "', '" + seatValue + "', '"
						+ flightID + "');");

			} catch (SQLException e) {
				System.err.println(e.getClass().getName() + ": " + e.getMessage());
				System.exit(0);
				System.out.println("Database query ok ");
			}
		}
	}

	@Override
	public Seat[] getAvailableSeats(String flightID) {
		Seat[] seats = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Seats\"";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();
			resultSet1.next();
			int amount = resultSet1.getInt("total");
			seats = new Seat[amount];
			selectSQL = "SELECT * FROM zair.\"Seats\" WHERE \"flightID\" = '" + flightID + "'";
			preparedStatement = c.prepareStatement(selectSQL);
			resultSet1 = preparedStatement.executeQuery();
			int i = 0;
			while (resultSet1.next()) {

				String seatPo = resultSet1.getString("seatPo");
				String seatValue = resultSet1.getString("seatValue");

				if (seatValue.equals("f")) {
					seats[i] = new Seat(seatPo);
					i++;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return seats;

	}

	private Seat[] getAllSeats(String flightID) {
		Seat[] seats = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Seats\"";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();
			resultSet1.next();
			int amount = resultSet1.getInt("total");
			seats = new Seat[amount];
			selectSQL = "SELECT * FROM zair.\"Seats\" WHERE \"flightID\" = '" + flightID + "'";
			preparedStatement = c.prepareStatement(selectSQL);
			resultSet1 = preparedStatement.executeQuery();
			int i = 0;
			while (resultSet1.next()) {

				String seatPo = resultSet1.getString("seatPo");
				String seatValue = resultSet1.getString("seatValue");
				seats[i] = new Seat(seatPo);
				if (seatValue.equals("t"))
					seats[i].setBooked();
				i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return seats;

	}

	@Override
	public Customer[] getAllCustomers() {
		Customer[] customers = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Customer\"";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();
			resultSet1.next();
			int amount = resultSet1.getInt("total");
			customers = new Customer[amount];
			selectSQL = "SELECT * FROM zair.\"Customer\"";
			preparedStatement = c.prepareStatement(selectSQL);
			resultSet1 = preparedStatement.executeQuery();
			int i = 0;
			while (resultSet1.next()) {

				String customerID = resultSet1.getString("customerID");
				String fname = resultSet1.getString("fName");
				String lname = resultSet1.getString("lName");
				String email = resultSet1.getString("email");
				String passportNo = resultSet1.getString("passportNo");
				String phone = resultSet1.getString("phone");
				customers[i] = new Customer(fname, lname, email, phone, passportNo,
						getCustomerCredentials(customerID).getUserId(),
						getCustomerCredentials(customerID).getPassword());
				Ticket[] tickets = getTickets(customers[i].getId());
				for (int j = 0; j < tickets.length; j++) {
					customers[i].addTicket(tickets[j]);
				}
				i++;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return customers;

	}

	@Override
	public void bookTicket(String flightID, String customerID, String seatValue, Ticket ticket) {
		try {
			stmt = c.createStatement();
			String ticketID = "" + ticket.getTicketID();
			String seatPo = "" + seatValue;
			System.out.println("INSERT INTO zair.\"Ticket\" " + "VALUES ('" + ticketID + "', '" + flightID + "', '"
					+ seatPo + "', '" + customerID + "');");

			stmt.executeUpdate("INSERT INTO zair.\"Ticket\" " + "VALUES ('" + ticketID + "', '" + flightID + "', '"
					+ seatPo + "', '" + customerID + "');");

			stmt = c.createStatement();
			System.out.println("UPDATE zair.\"Seats\" SET \"seatValue\"= true WHERE \"flightID\" = '" + flightID
					+ "' AND " + "\"seatPo\" = '" + seatValue + "';");
			stmt.executeUpdate("UPDATE zair.\"Seats\" SET \"seatValue\"= true WHERE	\"flightID\" = '" + flightID
					+ "' AND " + "\"seatPo\" = '" + seatValue + "';");

		} catch (SQLException e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
			System.out.println("Database query ok ");
		}
	}

	@Override
	public Ticket[] getTickets(String customerID) {
		Ticket[] tickets = null;
		try {
			stmt = c.createStatement();
			String selectSQL = "SELECT COUNT(*) AS total FROM zair.\"Ticket\"";
			PreparedStatement preparedStatement;
			preparedStatement = c.prepareStatement(selectSQL);
			ResultSet resultSet1 = preparedStatement.executeQuery();
			resultSet1.next();
			int amount = resultSet1.getInt("total");
			tickets = new Ticket[amount];
			selectSQL = "SELECT * FROM zair.\"Ticket\" WHERE \"customerID\"= '" + customerID +"'";
			preparedStatement = c.prepareStatement(selectSQL);
			resultSet1 = preparedStatement.executeQuery();
			int i = 0;
			while (resultSet1.next()) {

				String seatPo = resultSet1.getString("seatPo");
				String id = resultSet1.getString("flightID");
				tickets[i] = new Ticket(seatPo, getFlight(id));
				i++;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return tickets;
	}

	public static void main(String[] args) {
		FlightDatabase database = new FlightDatabase("2308", "mydb");
		Date dateOfDeparture = new Date(10, 10, 2018);
		Date dateOfArrival = new Date(11, 10, 2018);
		Flight flight = new Flight(dateOfDeparture, dateOfArrival, "Bucharest", "Copenhagen", "8:00", "10:45", 500);
		//database.addFlight(flight);
		//database.saveSeats(flight);
		//flight.getAllSeats().get(0).setBooked();
		Customer customer = new Customer("BOI", "GAY", "gaiboi", "700800", "2340RO", "gaytron", "2308");
		//database.addCustomer(customer);
		Ticket ticket = new Ticket("A1", flight);
		//database.bookTicket(flight.getId(), customer.getCustomerNo(), "A3", ticket);
		System.out.println(database.getAllCustomers()[0].getCustomerNo());
		System.out.println(database.getTickets(customer.getCustomerNo())[0].getSeatNumber());
		System.out.println(database.getAllSeats(flight.getId())[1].getSeatValue());
		System.out.println(database.getFlight(flight.getId()).getOrigin().getInitials());
		System.out.println(database.getAllFlights()[0].getSeats().get(59).getSeatValue());
		System.out.println(database.getAllFlights()[0].getSeats().get(59).isBooked());
		System.out.println(database.getAllCustomers()[0].getCredentials().getPassword());
		System.out.println(database.getAvailableSeats(flight.getId())[1].isBooked());
	}

}
